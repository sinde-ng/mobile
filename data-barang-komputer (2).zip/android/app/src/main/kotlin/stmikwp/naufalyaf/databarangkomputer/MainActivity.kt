package stmikwp.naufalyaf.databarangkomputer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
