import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'home.dart';

class Input extends StatefulWidget {
  @override
  _InputState createState() => _InputState();
}

class _InputState extends State<Input> {
  TextEditingController kodeController = TextEditingController();
  TextEditingController namaController = TextEditingController();
  TextEditingController hargaController = TextEditingController();
  TextEditingController spesifikasiController = TextEditingController();
  TextEditingController merekController = TextEditingController();
  void tambahData() {
    var url = Uri.parse("https://api.bams-wp.my.id/akademik/barang");
    http.post(url, body: {
      "kode": kodeController.text,
      "nama": namaController.text,
      "harga": hargaController.text,
      "spesifikasi": spesifikasiController.text,
      "merk": merekController.text,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ADD DATA"),
      ),
      body: Padding(
        padding: EdgeInsets.all(10.0),
        child: ListView(
          children: <Widget>[
            Text(
              "Input Data Barang",
              style: TextStyle(
                color: Colors.red,
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.bold,
                fontSize: 25,
              ),
            ),
            SizedBox(
              height: 40,
            ),
            TextFormField(
              controller: kodeController,
              decoration: InputDecoration(labelText: "Kode"),
            ),
            TextFormField(
              controller: namaController,
              decoration: InputDecoration(labelText: "Nama"),
            ),
            TextFormField(
              controller: hargaController,
              decoration: InputDecoration(labelText: "Harga"),
            ),
            TextFormField(
              controller: spesifikasiController,
              decoration: InputDecoration(labelText: "Spesifikasi"),
            ),
            TextFormField(
              controller: merekController,
              decoration: InputDecoration(labelText: "Merek"),
            ),
            SizedBox(
              height: 50,
            ),
            ElevatedButton(
              onPressed: () {
                tambahData();
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => Home()),
                  (Route<dynamic> route) => false,
                );
              },
              child: Text("Simpan"),
            ),
          ],
        ),
      ),
    );
  }
}
